import { Link } from 'react-router-dom'

const DeptRow = ({dept}) => {
  const {deptno, dname, loc} = dept
  return (
    <>
      <tr>
        <td>{deptno}</td>
        <td>
          <Link to={"/deptDetail/"+deptno}>{dname}</Link>
        </td>
        <td>{loc}</td>
      </tr>
    </>
  )
}

export default DeptRow