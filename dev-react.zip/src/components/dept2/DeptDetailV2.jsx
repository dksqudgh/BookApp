import { Button, Card, ListGroup, Modal } from "react-bootstrap"
import Footer from "../include/Footer"
import Header from "../include/Header"
import { Link, useParams } from "react-router-dom"
import { MyInput } from "../style/FormStyle"
import { useEffect, useState } from "react"

const DeptDetailV2 = ({depts,onDeleteItem,onUpdateItem}) => {
  const {p_deptno}=useParams()
  const[dname,setDname] = useState('')
  const[loc,setLoc] = useState('')
  console.log(p_deptno);
  useEffect(()=>{
    const deptItem = depts.find(item => item.deptno == p_deptno)
    setDept({...deptItem})
  },{p_deptno})
  const handleDname = (value) => {
    setDname(value)
  }
  const handleLoc = (value) => {
    setLoc(value)
  }
  const [dept,setDept]=useState({
    deptno:0,
    dname:'',
    loc:'',

  })
  const deptDelete = () => {
    const dept = {
      deptno:p_deptno,
      dname:'',
      loc:'',
    }
    onDeleteItem(dept)
  }
  const deptUpdate = () => {
    const udept = {
      deptno: p_deptno,
      dname:dname,
      loc:loc,
    }
    handleClose()
    onUpdateItem(udept)
  }
  const [show,setShow]=useState(false)
  const handleShow = ()=> setShow(true)
  const handleClose = ()=> setShow(false)
  return (
    <>
      <Header />
      <div className="container">
        <div className="page-header">
          <h2>부서관리 <small>상세정보</small></h2>
          <hr />
        </div>
        <Card style={{ width: '58rem' }}>
          <ListGroup variant="flush">
            <ListGroup.Item>부서번호 : {dept.deptno}</ListGroup.Item>
            <ListGroup.Item>부서명 : {dept.dname}</ListGroup.Item>
            <ListGroup.Item>지역 : {dept.loc}</ListGroup.Item>
          </ListGroup>
          <div className='detail-link'>
            <Button variant="success" onClick={handleShow}>
              수정
            </Button>
            &nbsp;
            <Button variant="danger" onClick={deptDelete}>
              삭제
            </Button>
            &nbsp;
            <Link to="/dept2" className='nav-link'>목록</Link>
          </div>
        </Card>   
        <hr />
      {/* ========================== [[ 수정 Modal ]] ========================== */}
      <Modal show={show} onHide={handleClose} animation={false}>
        <Modal.Header closeButton>
          <Modal.Title>상세정보수정</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div style={{display: 'flex', flexWrap: 'wrap', justifyContent: 'center'}}>
            <div style={{display: 'flex'}}>
              <MyInput type="text" id="deptno" value={dept.deptno} readOnly placeholder="Enter 부서번호" />
            </div>
            <div style={{display: 'flex'}}>
              <MyInput type="text" id="dname" placeholder="Enter 부서명" onChange={(e)=>{handleDname(e.target.value)}}/>
            </div>
            <div style={{display: 'flex'}}>
              <MyInput type="text" id="loc" placeholder="Enter 지역" onChange={(e)=>{handleLoc(e.target.value)}}/>
            </div>
          </div>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            닫기
          </Button>
          <Button variant="primary" onClick={deptUpdate}>
            저장
          </Button>
        </Modal.Footer>
      </Modal>     
      {/* ========================== [[ 수정 Modal ]] ========================== */}          
      </div>
      <Footer />
    </>
  )
}

export default DeptDetailV2