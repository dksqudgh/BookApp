import React from 'react'

const BoardList = () => {
  return (
    <div>BoardList</div>
  )
}

export default BoardList