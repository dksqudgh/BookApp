package com.example.demo.vo;

import lombok.Data;

@Data
public class DeptVO {
    private int deptno=0;
    private String dname=null;
    private String loc=null;
}
